import { useState } from "react";
import Carousel from "react-bootstrap/Carousel";
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import Table from "react-bootstrap/Table";

function ControlledCarousel() {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  return (
    <div>
      <Carousel activeIndex={index} onSelect={handleSelect}>
        <Carousel.Item>
          <Carousel.Caption>
            <h3>First team</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <Carousel.Caption>
            <h3>Second team</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <Carousel.Caption>
            <h3>Third team</h3>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      <Card>
        <Card.Header>Sports Featured</Card.Header>
        <Card.Body>
          <Card.Title>A quick treatment of any sports fans</Card.Title>
          <Card.Text>Additional content for the sports teams</Card.Text>
          <Button variant="primary">Here it is!</Button>
        </Card.Body>
      </Card>

      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Games: </th>
            <th>Team 1:</th>
            <th>Team 2: </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Team A</td>
            <td>Team B</td>
          </tr>
          <tr>
            <td>2</td>
            <td>Team C</td>
            <td>Team D</td>
          </tr>
          <tr>
            <td>3</td>
            <td>Team E</td>
            <td>Team F</td>
          </tr>
        </tbody>
      </Table>
    </div>
  );
}

export default ControlledCarousel;
