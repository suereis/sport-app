import Card from "react-bootstrap/Card";

function Sportcard() {
  return (
    <>
      <Card>
        <Card.Img
          variant="top"
          src="https://t3.ftcdn.net/jpg/05/43/09/94/360_F_543099455_t7u3dj6pu4PItiS5BBVrbuj19vpyp9tb.jpg"
        />
        <Card.Body>
          <Card.Text>
            Basketball is a team sport of 2 teams of 5 players thatto score by
            throwing the ball at high hoops under certain rules. Played by
            indoors or outdoors and can be done by anyone.
          </Card.Text>
        </Card.Body>
      </Card>
    </>
  );
}

export default Sportcard;
